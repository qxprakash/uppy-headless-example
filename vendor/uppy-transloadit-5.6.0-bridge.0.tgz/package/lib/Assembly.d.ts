import type { RateLimitedQueue } from '@uppy/utils';
import Emitter from 'component-emitter';
import { type AssemblyResponse } from './index.js';
declare class TransloaditAssembly extends Emitter {
    #private;
    pollInterval: ReturnType<typeof setInterval> | null;
    closed: boolean;
    constructor(assembly: AssemblyResponse, rateLimitedQueue: RateLimitedQueue);
    connect(): void;
    get status(): AssemblyResponse;
    set status(status: AssemblyResponse);
    update(): Promise<void>;
    /**
     * Update this assembly's status with a full new object. Events will be
     * emitted for status changes, new files, and new results.
     */
    updateStatus(next: AssemblyResponse): void;
    /**
     * Stop updating this assembly.
     */
    close(): void;
}
export default TransloaditAssembly;
//# sourceMappingURL=Assembly.d.ts.map
import type { AssemblyInstructionsInput, AssemblyStatus, AssemblyStatusResult, AssemblyStatusUpload } from '@transloadit/types';
import type { Body, DefinePluginOpts, Meta, PluginOpts, Uppy, UppyFile } from '@uppy/core';
import { BasePlugin } from '@uppy/core';
import { type TusOpts } from '@uppy/tus';
import Assembly from './Assembly.js';
import Client from './Client.js';
export type AssemblyResponse = AssemblyStatus & {
    progress_combined?: number;
};
export type AssemblyFile = AssemblyStatusUpload;
export type AssemblyResult = AssemblyStatusResult & {
    localId: string | null;
};
export type AssemblyParameters = AssemblyInstructionsInput;
export interface AssemblyOptions {
    params?: AssemblyParameters | string | null;
    fields?: Record<string, string | number> | string[] | null;
    signature?: string | null;
}
export type OptionsWithRestructuredFields = Omit<AssemblyOptions, 'fields'> & {
    fields: Record<string, string | number>;
};
export interface TransloaditOptions<_M extends Meta, _B extends Body> extends PluginOpts {
    service?: string;
    errorReporting?: boolean;
    waitForEncoding?: boolean;
    waitForMetadata?: boolean;
    importFromUploadURLs?: boolean;
    alwaysRunAssembly?: boolean;
    limit?: number;
    clientName?: string | null;
    retryDelays?: number[];
    assemblyOptions?: AssemblyOptions | (() => Promise<AssemblyOptions> | AssemblyOptions);
}
declare const defaultOptions: {
    service: string;
    errorReporting: true;
    waitForEncoding: false;
    waitForMetadata: false;
    alwaysRunAssembly: false;
    importFromUploadURLs: false;
    limit: number;
    retryDelays: number[];
    clientName: null;
};
export type Opts<M extends Meta, B extends Body> = DefinePluginOpts<TransloaditOptions<M, B>, keyof typeof defaultOptions>;
type TransloaditState = {
    files: Record<string, {
        assembly: string;
        id: string;
        uploadedFile: AssemblyFile;
    }>;
    /**
     * Live status of the currently-active assembly. Tracks every status
     * transition (UPLOADING → EXECUTING → ...). Cleared automatically when
     * `this.assembly = undefined` (no live assembly).
     */
    assemblyStatus: AssemblyResponse | undefined;
    /**
     * Snapshot of the most recent non-null status seen. Persists across the
     * gap between uploads so the UI can keep showing "your last upload's
     * result" after `assemblyStatus` clears. Overwritten by the next
     * status update routed through `#handleAssemblyStatusUpdate`.
     */
    lastAssemblyStatus: AssemblyResponse | undefined;
    results: Array<{
        result: AssemblyResult;
        stepName: string;
        id: string;
        assembly: string;
    }>;
};
/**
 * State we want to store in Golden Retriever to be able to recover uploads.
 */
type PersistentState = {
    assemblyResponse: AssemblyResponse;
};
declare module '@uppy/core' {
    interface UppyEventMap<M extends Meta, B extends Body> {
        restored: (pluginData: Record<string, PersistentState>) => void;
        'restore:plugin-data-changed': (pluginData: Record<string, PersistentState | undefined>) => void;
        'transloadit:assembly-created': (assembly: AssemblyResponse, fileIDs: string[]) => void;
        'transloadit:assembly-cancel': (assembly: AssemblyResponse) => void;
        'transloadit:import-error': (assembly: AssemblyResponse, fileID: string, error: Error) => void;
        'transloadit:assembly-error': (assembly: AssemblyResponse, error: Error) => void;
        'transloadit:assembly-executing': (assembly: AssemblyResponse) => void;
        'transloadit:assembly-cancelled': (assembly: AssemblyResponse) => void;
        'transloadit:upload': (file: AssemblyFile, assembly: AssemblyResponse) => void;
        'transloadit:result': (stepName: string, result: AssemblyResult, assembly: AssemblyResponse) => void;
        'transloadit:complete': (assembly: AssemblyResponse) => void;
        'transloadit:execution-progress': (details: {
            progress_combined?: number;
        }) => void;
    }
    interface PluginTypeRegistry<M extends Meta, B extends Body> {
        Transloadit: Transloadit<M, B>;
    }
}
declare module '@uppy/utils' {
    interface LocalUppyFile<M extends Meta, B extends Body> {
        transloadit?: {
            assembly: string;
        };
        tus?: TusOpts<M, B>;
    }
    interface RemoteUppyFile<M extends Meta, B extends Body> {
        transloadit?: {
            assembly: string;
        };
        tus?: TusOpts<M, B>;
    }
}
export declare function getAssemblyUrl(assembly: Pick<AssemblyResponse, 'assembly_ssl_url' | 'assembly_url'>): string;
export declare function getAssemblyUrlSsl(assembly: Pick<AssemblyResponse, 'assembly_ssl_url' | 'assembly_url'>): string;
declare const COMPANION_URL = "https://api2.transloadit.com/companion";
declare const COMPANION_ALLOWED_HOSTS: RegExp;
/**
 * Upload files to Transloadit using Tus.
 */
export default class Transloadit<M extends Meta, B extends Body> extends BasePlugin<Opts<M, B>, M, B, TransloaditState> {
    #private;
    static VERSION: string;
    static COMPANION_URL: string;
    static COMPANION_ALLOWED_HOSTS: RegExp;
    client: Client<M, B>;
    completedFiles: Record<string, boolean>;
    restored: Promise<void> | null;
    constructor(uppy: Uppy<M, B>, opts?: TransloaditOptions<M, B>);
    get assembly(): Assembly | undefined;
    set assembly(newAssembly: Assembly | undefined);
    install(): void;
    uninstall(): void;
    getAssembly(): AssemblyResponse | undefined;
    getAssemblyFiles(assemblyID: string): UppyFile<M, B>[];
}
export { COMPANION_URL, COMPANION_ALLOWED_HOSTS };
export type { AssemblyInstructionsInput } from '@transloadit/types';
export { default as Assembly } from './Assembly.js';
export { AssemblyError, default as Client } from './Client.js';
//# sourceMappingURL=index.d.ts.map
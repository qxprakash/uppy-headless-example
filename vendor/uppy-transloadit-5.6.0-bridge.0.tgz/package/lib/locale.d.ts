declare const _default: {
    strings: {
        creatingAssembly: string;
        creatingAssemblyFailed: string;
        encoding: string;
    };
};
export default _default;
//# sourceMappingURL=locale.d.ts.map